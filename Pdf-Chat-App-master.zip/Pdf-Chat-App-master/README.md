# Pdf-Chat-App


<img width="479" alt="image" src="https://github.com/Jhanvi528/Pdf-Chat-App/assets/77280638/84c30dc7-9223-4aa5-8f62-622cd3803c4c">


<img width="500" alt="image" src="https://github.com/Jhanvi528/Pdf-Chat-App/assets/77280638/c7a02103-a9c3-42ea-8dd7-906c22978555">
